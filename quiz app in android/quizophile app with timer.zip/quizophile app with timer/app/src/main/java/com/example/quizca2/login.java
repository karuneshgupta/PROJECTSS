package com.example.quizca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class login extends AppCompatActivity {
    EditText email, password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);

    }

//    @Override
//    public void onBackPressed() {
//        Intent i = new Intent(getApplicationContext(),MainActivity.class);
//        startActivity(i);
//    }

    String username[] = { "a","guptakarunesh13", "arunimagupta","yashkumar","harshitdhiman","sarishmamam" };

    String passwords[] = {"a","karunesh1234" , "arunima5678" , "yash1234","harshit5678","sarishma222"};

//
//    public void login(View view) {
//        if (email.getText().toString().equals("guptakarunesh13@gmail.com") && password.getText().toString().equals("1234")) {
//            Intent i = new Intent(this, home.class);
//            startActivity(i);
//        }
//        else{
//            Toast.makeText(getApplicationContext(),"Incorrect Credentials", Toast.LENGTH_LONG).show();
//        }
//    }
//}

    public void login(View view) {
        for(int i= 0 ;i<username.length ;i++)
        {
            if (email.getText().toString().equals(username[i])) {
                if(password.getText().toString().equals(passwords[i]))
                {
                Intent j = new Intent(this, home.class);
                startActivity(j);
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}

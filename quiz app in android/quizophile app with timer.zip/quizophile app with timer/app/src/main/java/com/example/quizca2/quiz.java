package com.example.quizca2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Timer;
import java.util.TimerTask;

public class quiz extends AppCompatActivity {

    TextView timertext;

    TextView tv;
    Button submitbutton, quitbutton;
    RadioGroup radio_g;
    RadioButton rb1, rb2, rb3, rb4;

    String questions[] = {
            "Who invented Java Programming?",
            "Which statement is true about Java?",
            "Which component is used to compile, debug and execute the java programs?",
            "Which one of the following is not a Java feature?",
            " Which of these cannot be used for a variable name in Java?",
            "What is the extension of java code files?",
            "Which of the following is not an OOPS concept in Java?",
            "Which exception is thrown when java is out of memory?",
            "Which of these method of class String is used to compare two String objects for their equality?",
            "An expression involving byte, int, & literal numbers is promoted to which of these?"
    };
    String answers[] = {"James Gosling", "Java is a platform-independent",
            "JDK", "Use of pointers", "keyword", ".java", "Compilation", "OutOfMemoryError", "equals()", "int"};
    String opt[] = {
            " Guido van Rossum", "James Gosling", "Dennis Ritchie", "Bjarne Stroustrup",
            "Java is a sequence-dependent", "Java is a code dependent", "Java is a platform-dependent", "Java is a platform-independent",
            "JRE", "JIT", "JDK", "JVM",
            "Object-oriented", "Use of pointers", "Portable", "Dynamic and Extensible",
            "identifier & keyword", "identifier", "keyword", "All of the mentioned",
            ".js", ".txt", ".class", ".java",
            "polymorphism", "inheritance", "Compilation", "None of the mentioned",
            "MemoryError", "OutOfMemoryError", "MemoryOutOfBoundsException", "MemoryFullException",
            "equals()", "Equals()", "isequal()", "Isequal()",
            "int", "long", "byte", "float"
    };
    int flag = 0;
    public static int marks = 0, correct = 0, wrong = 0,count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        timerStart();

        final TextView score = (TextView) findViewById(R.id.textView4);

        submitbutton = (Button) findViewById(R.id.button3);
        quitbutton = (Button) findViewById(R.id.buttonquit);
        tv = (TextView) findViewById(R.id.tvque);

        radio_g = (RadioGroup) findViewById(R.id.answersgrp);
        rb1 = (RadioButton) findViewById(R.id.radioButton);
        rb2 = (RadioButton) findViewById(R.id.radioButton2);
        rb3 = (RadioButton) findViewById(R.id.radioButton3);
        rb4 = (RadioButton) findViewById(R.id.radioButton4);
        tv.setText(questions[flag]);
        rb1.setText(opt[0]);
        rb2.setText(opt[1]);
        rb3.setText(opt[2]);
        rb4.setText(opt[3]);
        submitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // when no options is selected
                if (radio_g.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(getApplicationContext(), "Please select one choice", Toast.LENGTH_SHORT).show();
                    return;
                }
                 // when any options is selscted from radio group
                RadioButton uans = (RadioButton) findViewById(radio_g.getCheckedRadioButtonId());
                String ansText = uans.getText().toString();
                if (ansText.equals(answers[flag])) {
                    correct++;
                    count++;
                    Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                } else {
                    wrong++;
                    count++;
                    Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                }

                flag++;

                if (score != null)
                    score.setText("" + correct);
                // for next question updating options and question in the quiz activity
                if (flag < questions.length) {
                    tv.setText(questions[flag]);
                    rb1.setText(opt[flag * 4]);
                    rb2.setText(opt[flag * 4 + 1]);
                    rb3.setText(opt[flag * 4 + 2]);
                    rb4.setText(opt[flag * 4 + 3]);
                } else {
                    // when flag value exceeeds number of questions
                    marks = correct;
                    Intent in = new Intent(getApplicationContext(), results.class);
                    startActivity(in);
                }
                radio_g.clearCheck();

            }
        });

        quitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), results.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public void onBackPressed() {
    }

    private void timerStart() {

        timertext = findViewById(R.id.timertxt);

        // time  = 15 min  = 900000 ms;
        // 10 min = 600000
        new CountDownTimer(600000,1000){
            @Override
            public void onTick(long l) {

                NumberFormat f = new DecimalFormat("00");
                long hour = (l/3600000) %24;
                long min = (l/60000) %60;
                long sec = (l/1000) %60;

                timertext.setText(f.format(hour) + ":" + f.format(min) + ":" + f.format(sec));
            }

            @Override
            public void onFinish() {
                timertext.setText("TEST ENDED");

                Intent intent = new Intent(getApplicationContext(), results.class);
                startActivity(intent);
            }
        }.start();

    }


}
